first part is in Matlab and second part is in c++ Visual Studio 2013 opencv 2.4.11

in first part there are 5 files 
run the firstGUI.m in matlab keeping all the other files
1)	first browse image and open it in GUI 
2)	then use data curser icon on the window and select the corresponding 4 points and also insert the values of the coordinates in the table
3) 	click start and the corresponding image will be saved with the same name but with the prefix new

in the second part 
1)	we have the c++ file Source.cpp
2)	run it and the new required files will be saved 