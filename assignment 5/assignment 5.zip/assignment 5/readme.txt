In this assignment 5 
we need to run main_file1.m 
the file named RGBD data should be in the working directory
total 5 txt files will be created each showing the local topology 

it will display local topology for each coordinate 

in principal curvature case 
the mapping is like 
keySet = [1,2,3,4,5,6,7,8,9];
valueSet1 = {'peak','ridge','saddle','ridge','flat','valley','saddle','valley','pit'};

in mean and gaussian curvature case 
the mapping is like 
keySet = [1,2,3,4,5,6,7,8,9];
valueSet2 = {'peak','ridge','Saddle ridge','none','flat','Minimal surface','pit','valley','Saddle valley'};
